MUAZZIN DIARY — ANDROID PROJECT

Yeh Android project aapki di hui 3.11.Muazzin.html ko app ke assets/index.html mein bilkul byte-for-byte copy karta hai. Original HTML ke design ya features ko rewrite nahi kiya gaya.

App:
- Naam: Muazzin Diary
- Package: com.muazzin.diary
- Android minimum: Android 6.0 (API 23)
- HTML local asset URL par chalegi; isse Diary ka localStorage app ke WebView origin mein save hota hai.
- JavaScript, DOM storage, photo file chooser aur geolocation support configured hain.
- Location ka Android permission prompt ab user se permission maangega; bina ijazat location access nahi hoga.
- Android automatic app-data backup band hai, taaki Diary ka private data device ke system backup mein apne-aap na jaye. App ka manual Backup/Restore feature alag se available rahega.
- Camera permission manifest se hata di gayi hai; photo chunne ke liye Android file/photo picker istemal hota hai.
- Text/link sharing ke liye Android ka native Share sheet support hai.
- PNG aur anya files ke liye Web Share API ko Android native attachment sharing se joda gaya hai; FileProvider private cache URI deta hai. Share operation ka result web page ko wapas milta hai, taaki share sheet khulne par Promise resolve ho aur failure par reject ho.
- Share limit: adhiktam 10 files, har file 12 MB tak aur kul 24 MB tak. Purani temporary share files 24 ghante baad cleanup hoti hain.
- Share bridge sirf app ke main local page origin se message accept karta hai; third-party iframe ko bridge access nahi milta.

BUILD:
1. Android Studio install/open karein.
2. File > Open se wahi extracted folder kholein jahan settings.gradle.kts file maujood hai.
3. Gradle sync hone dein; internet se Android Gradle Plugin aur dependencies download hongi.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. Debug APK app/build/outputs/apk/debug/app-debug.apk mein milega.

TEST ZAROOR KAREIN:
- PIN / Forgot PIN
- Note lock/unlock
- Notes save, close/reopen aur app restart ke baad persistence
- Photos add/open
- Search, favourite, text/link share aur recently deleted
- PNG/HTML file ko Android Share sheet mein attachment ke roop mein bhejna aur file download
- Backup/restore (JSON file picker/save flow)
- Back button, screen rotation aur location permission prompt

BUILD STATUS:
Is project ko is environment mein APK ke roop mein compile nahi kiya gaya, kyunki Android SDK aur Gradle build executable yahan maujood nahi hain. Gradle wrapper JAR bhi project mein available nahi hai; Android Studio se project open karte waqt agar wrapper setup ka error aaye, to Android Studio ke Gradle configuration se local/downloaded Gradle 8.9 select karke sync karein. Physical Android phone par final feature testing abhi baaki hai.

AUTOMATIC APK BUILD (GitHub Actions):
- ZIP extract karein aur is folder ke andar ki sabhi files/folders (app, .github, scripts, settings.gradle.kts, etc.) ko seedha naye GitHub repository ke root mein upload/push karein. Extra Diary-Android parent folder repository ke andar na banayein.
- Repository ke Actions tab mein “Build Muazzin Diary APK” workflow kholein. Main/master par push aur pull request par bhi build check chalega.
- “Run workflow” dabayein; ya main/master branch par push karne par build automatic chalega.
- Build successful hone par workflow run ke Artifacts section se “Muazzin-Diary-debug-APK” download karein. Pull request builds par bhi compile check hoga; artifact workflow run mein upload hoga.
- ZIP ke andar .github/workflows/android-build.yml pehle se diya hai. Yeh GitHub ke hosted runner par JDK 17, Android SDK 35 aur Gradle 8.9 set karke debug APK banata hai.
- Yeh workflow abhi add kiya gaya hai; GitHub par chalakar successful APK banana abhi baaki hai.

IMPORTANT:
Yeh abhi Android project source hai, final APK nahi. WebView mein Chrome ke har browser API ka behavior identical hone ki guarantee nahi di ja sakti. Text/link aur supported file attachments ke liye Android Share sheet bridge joda gaya hai. Native file-sharing behavior ko physical phone par test karna zaroori hai. Downloads, backup/restore aur photo flows ko phone par test karna zaroori hai.

Build se pehle integrity check
------------------------------
GitHub Actions APK compile karne se pehle scripts/verify_project.py chalata hai.
Yeh check karta hai ki app ke andar Diary HTML ka SHA-256 original verified
value se match karta hai, Android automatic backup band hai, cleartext HTTP
band hai, aur FileProvider sirf private diary-share cache folder expose karta hai.
Kisi check ke fail hone par APK build rok diya jayega.

Local check chalane ke liye project root mein:
  python3 scripts/verify_project.py
