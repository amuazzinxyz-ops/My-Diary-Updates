#!/usr/bin/env python3
"""Pre-build integrity and Android packaging checks for Muazzin Diary."""
from pathlib import Path
import hashlib
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_HTML_SHA256 = "c242a422405dd58c71f0415a3760e1d4863ae9902143690a86772416afd3fdf2"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

html = ROOT / "app/src/main/assets/index.html"
if not html.is_file():
    fail("Original Diary HTML is missing from app/src/main/assets/index.html")
actual_hash = hashlib.sha256(html.read_bytes()).hexdigest()
if actual_hash != EXPECTED_HTML_SHA256:
    fail(f"Diary HTML hash mismatch. Expected {EXPECTED_HTML_SHA256}, got {actual_hash}")
print(f"PASS: Original Diary HTML SHA-256 {actual_hash}")

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
try:
    manifest = ET.parse(manifest_path).getroot()
except (ET.ParseError, OSError) as exc:
    fail(f"AndroidManifest.xml is invalid: {exc}")

app = manifest.find("application")
if app is None:
    fail("AndroidManifest.xml has no application element")
if app.get(ANDROID_NS + "allowBackup") != "false":
    fail("Android automatic backup must remain disabled for private Diary data")
if app.get(ANDROID_NS + "usesCleartextTraffic") != "false":
    fail("Cleartext HTTP traffic must remain disabled")
provider = app.find("provider")
if provider is None or provider.get(ANDROID_NS + "exported") != "false" or provider.get(ANDROID_NS + "grantUriPermissions") != "true":
    fail("FileProvider must be non-exported and grant URI permissions")
paths = ROOT / "app/src/main/res/xml/file_paths.xml"
try:
    paths_root = ET.parse(paths).getroot()
except (ET.ParseError, OSError) as exc:
    fail(f"FileProvider paths XML is invalid: {exc}")
cache_paths = paths_root.findall("cache-path")
if not any(p.get("path") == "diary-share/" for p in cache_paths):
    fail("FileProvider must expose only the diary-share cache directory")

activity = ROOT / "app/src/main/java/com/muazzin/diary/MainActivity.kt"
if not activity.is_file():
    fail("MainActivity.kt is missing")
print("PASS: Android manifest, private FileProvider paths, and app entry point")
print("All pre-build integrity checks passed.")
