package com.muazzin.diary

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.app.DownloadManager
import android.os.Environment
import android.webkit.URLUtil
import android.os.Bundle
import android.util.Base64
import android.content.ClipData
import androidx.core.content.FileProvider
import java.io.File
import android.Manifest
import android.content.pm.PackageManager
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import androidx.webkit.WebViewClientCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allowed = (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true) ||
            (grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
        pendingGeoCallback?.invoke(pendingGeoOrigin, allowed, false)
        pendingGeoCallback = null
        pendingGeoOrigin = null
    }
    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = if (result.resultCode == Activity.RESULT_OK) result.data else null
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val root = FrameLayout(this)
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(webView, "DiaryNativeShare", setOf("https://appassets.androidplatform.net")) { _, message, sourceOrigin, isMainFrame, replyProxy ->
                if (isMainFrame && sourceOrigin.toString() == "https://appassets.androidplatform.net") {
                    try {
                        val data = JSONObject(message.data ?: "{}")
                        val title = data.optString("title", "Muazzin Diary").take(120)
                        val text = data.optString("text", "").take(100000)
                        val pageUrl = data.optString("url", "")
                        val content = buildString {
                            append(text)
                            if (pageUrl.startsWith("https://") || pageUrl.startsWith("http://")) {
                                if (isNotEmpty()) append("\n")
                                append(pageUrl)
                            }
                        }
                        val files = data.optJSONArray("files")
                        val sharedUris = ArrayList<Uri>()
                        var totalBytes = 0L
                        if (files != null) {
                            if (files.length() > 10) throw IllegalArgumentException("Too many files")
                            val shareDir = File(cacheDir, "diary-share").apply { mkdirs() }
                            shareDir.listFiles()?.forEach { old ->
                                if (System.currentTimeMillis() - old.lastModified() > 24L * 60 * 60 * 1000) old.delete()
                            }
                            for (i in 0 until files.length()) {
                                val item = files.getJSONObject(i)
                                val rawName = item.optString("name", "diary-file-$i")
                                val safeName = rawName.substringAfterLast('/').substringAfterLast('\\')
                                    .replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "diary-file-$i" }
                                val mime = item.optString("type", "application/octet-stream").take(120)
                                val encoded = item.optString("data", "")
                                val estimated = (encoded.length.toLong() * 3L) / 4L
                                totalBytes += estimated
                                if (estimated > 12L * 1024 * 1024 || totalBytes > 24L * 1024 * 1024) throw IllegalArgumentException("Shared file size limit exceeded")
                                val bytes = Base64.decode(encoded, Base64.DEFAULT)
                                if (bytes.size > 12 * 1024 * 1024 || totalBytes > 24L * 1024 * 1024) throw IllegalArgumentException("Shared file size limit exceeded")
                                val output = File(shareDir, "${System.currentTimeMillis()}-$i-$safeName")
                                output.writeBytes(bytes)
                                sharedUris.add(FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", output))
                            }
                        }
                        val intent = if (sharedUris.isNotEmpty()) {
                            if (sharedUris.size == 1) Intent(Intent.ACTION_SEND).apply {
                                type = data.optJSONArray("files")!!.getJSONObject(0).optString("type", "application/octet-stream")
                                putExtra(Intent.EXTRA_STREAM, sharedUris[0])
                            } else Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                type = "*/*"
                                putParcelableArrayListExtra(Intent.EXTRA_STREAM, sharedUris)
                            }
                        } else Intent(Intent.ACTION_SEND).apply { type = "text/plain" }
                        intent.putExtra(Intent.EXTRA_SUBJECT, title)
                        if (content.isNotBlank()) intent.putExtra(Intent.EXTRA_TEXT, content)
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        if (sharedUris.isNotEmpty()) {
                            val clip = ClipData.newUri(contentResolver, title, sharedUris[0])
                            for (i in 1 until sharedUris.size) clip.addItem(ClipData.Item(sharedUris[i]))
                            intent.clipData = clip
                        }
                        runOnUiThread {
                            try {
                                startActivity(Intent.createChooser(intent, title))
                                replyProxy.postMessage("{\"ok\":true}")
                            } catch (_: Exception) {
                                replyProxy.postMessage("{\"ok\":false,\"error\":\"Share sheet could not be opened\"}")
                            }
                        }
                    } catch (_: Exception) {
                        replyProxy.postMessage("{\"ok\":false,\"error\":\"Sharing failed. Check file size and format.\"}")
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClientCompat() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (url == "https://appassets.androidplatform.net/assets/index.html") {
                    // Provide Android's native text-share sheet while leaving the original HTML untouched.
                    view.evaluateJavascript("""(function(){
                      if(window.__diaryNativeShareReady)return;window.__diaryNativeShareReady=true;
                      try{Object.defineProperty(navigator,'share',{configurable:true,value:async function(data){data=data||{};var files=[];if(data.files&&data.files.length){if(data.files.length>10)throw new DOMException('Too many files','NotSupportedError');var total=0;for(var i=0;i<data.files.length;i++){var f=data.files[i];if(!(f instanceof Blob))throw new DOMException('Invalid file','TypeError');if(f.size>12*1024*1024||(total+=f.size)>24*1024*1024)throw new DOMException('File size limit exceeded','NotSupportedError');var encoded=await new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result).split(',')[1]||'');};r.onerror=function(){reject(r.error||new Error('File read failed'));};r.readAsDataURL(f);});files.push({name:String(f.name||('diary-file-'+i)),type:String(f.type||'application/octet-stream'),data:encoded});}}return await new Promise(function(resolve,reject){var done=false;function finish(event){if(done)return;done=true;DiaryNativeShare.removeEventListener('message',finish);try{var result=JSON.parse(event.data||'{}');if(result.ok)resolve();else reject(new Error(result.error||'Sharing failed'));}catch(e){reject(e);}}DiaryNativeShare.addEventListener('message',finish);DiaryNativeShare.postMessage(JSON.stringify({title:String(data.title||'Muazzin Diary'),text:String(data.text||''),url:String(data.url||''),files:files}));});}});
                      Object.defineProperty(navigator,'canShare',{configurable:true,value:function(data){if(!data||!data.files)return true;if(data.files.length>10)return false;var total=0;for(var i=0;i<data.files.length;i++){var f=data.files[i];if(!f||typeof f.size!=='number'||f.size>12*1024*1024||(total+=f.size)>24*1024*1024)return false;}return true;}});
                      }catch(e){}
                    })();""", null)
                }
            }
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return if (url.host == "appassets.androidplatform.net") false else {
                    if (url.scheme == "https" || url.scheme == "http") {
                        try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (_: Exception) {}
                    }
                    true
                }
            }
        }
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            // Route ordinary HTTP(S) downloads (including exported JSON/PNG files)
            // through Android's system Downloads service.
            if (url.startsWith("https://") || url.startsWith("http://")) {
                try {
                    val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimeType)
                        addRequestHeader("User-Agent", userAgent)
                        setTitle(filename)
                        setDescription("Downloading Diary file")
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    }
                    (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                } catch (_: Exception) {
                    // Keep the Diary usable if Android rejects a download request.
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    filePicker.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    false
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fine || coarse) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    locationPermission.launch(arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                // Do not silently grant camera/microphone permissions. The diary file picker
                // handles photo selection without granting broad WebView permissions.
                request.deny()
            }
        }
        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        pendingGeoCallback?.invoke(pendingGeoOrigin, false, false)
        pendingGeoCallback = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
